#ifndef __LINUX_BYTEORDER_SWAB_WRAPPER_H
#define __LINUX_BYTEORDER_SWAB_WRAPPER_H 1

#include_next <linux/byteorder/swab.h>

#undef __swab16
#define __swab16(x)				\
	(__builtin_constant_p((__u16)(x)) ?	\
	___constant_swab16(x) :			\
	__fswab16(x))

#undef __swab32
#define __swab32(x)				\
	(__builtin_constant_p((__u32)(x)) ?	\
	___constant_swab32(x) :			\
	__fswab32(x))

#undef __swab64
#define __swab64(x)				\
	(__builtin_constant_p((__u64)(x)) ?	\
	___constant_swab64(x) :			\
	__fswab64(x))

#endif
