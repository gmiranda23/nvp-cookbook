#ifndef __LINUX_NET_WRAPPER_H
#define __LINUX_NET_WRAPPER_H 1

#include_next <linux/net.h>

#include <linux/version.h>
#ifndef HAVE_KERNEL_BIND
static inline int kernel_bind(struct socket *sock, struct sockaddr *addr,
			      int addrlen)
{
	return sock->ops->bind(sock, addr, addrlen);
}
#endif

#endif
