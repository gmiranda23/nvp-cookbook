#ifndef __LINUX_NETFILTER_WRAPPER_H
#define __LINUX_NETFILTER_WRAPPER_H

#include_next <linux/netfilter.h>

#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
#define NFPROTO_IPV4 PF_INET
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
#include <linux/netfilter_ipv4.h>

#define NF_INET_LOCAL_IN NF_IP_LOCAL_IN
#endif

#endif
