#ifndef __NET_SOCK_WRAPPER_H
#define __NET_SOCK_WRAPPER_H 1

#include_next <net/sock.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24)
struct net;

static inline struct net *sock_net(const struct sock *sk)
{
	return NULL;
}

#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
#define sk_change_net rpl_sk_change_net
static inline void sk_change_net(struct sock *sk, struct net *net)
{

}

static inline void sk_release_kernel(struct sock *sk)
{
	sock_release(sk->sk_socket);
}
#endif

#endif /* net/sock.h wrapper */
