#ifndef __NET_TCP_WRAPPER_H
#define __NET_TCP_WRAPPER_H 1

#include_next <net/tcp.h>

#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,21)
#define tcp_v4_check(len, saddr, daddr, base) \
	tcp_v4_check(NULL, len, saddr, daddr, base)
#endif

#endif
