/*
 * Copyright (c) 2007-2011 Nicira, Inc.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA
 */

#ifdef CONFIG_NETFILTER

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <asm/unaligned.h>

#include <linux/module.h>
#include <linux/delay.h>
#include <linux/flex_array.h>
#include <linux/if.h>
#include <linux/if_vlan.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/jhash.h>
#include <linux/list.h>
#include <linux/log2.h>
#include <linux/netfilter.h>
#include <linux/percpu.h>
#include <linux/skbuff.h>
#include <linux/tcp.h>
#include <linux/version.h>
#include <linux/workqueue.h>
#include <linux/xfrm.h>

#include <net/icmp.h>
#include <net/inet_ecn.h>
#include <net/ip.h>
#include <net/net_namespace.h>
#include <net/sock.h>
#include <net/tcp.h>
#include <net/xfrm.h>

#include "checksum.h"
#include "datapath.h"
#include "tunnel.h"
#include "vlan.h"
#include "vport.h"
#include "vport-generic.h"

#ifdef CONFIG_SLUB
/*
 * Kernel older than 3.1 panics when STT try to borrow compound page
 * and TRANSPARENT_HUGEPAGE is turned on.  We have seen this when
 * SLUB is memory allocator. Slab generally avoids compound pages,
 * but to be safe, page borrowing is always skipped for compound pages
 * even if SLAB is been used.
 * Once we have better understanding of this bug we can have better fix.
 * During this investigation we saw better performance with skipping zero
 * copy in case of SLUB. So its on is on for all SLUB cases.
 */
#define SKIP_ZERO_COPY
#endif

#define STT_DST_PORT 7471
#define STT_IPSEC_SRC_PORT 7470

/* Padding after the end of the tunnel headers to provide alignment
 * for inner packet IP header after 14 byte Ethernet header.
 */
#define STT_ETH_PAD 2

#define STT_CSUM_VERIFIED	(1 << 0)
#define STT_CSUM_PARTIAL	(1 << 1)
#define STT_PROTO_IPV4		(1 << 2)
#define STT_PROTO_TCP		(1 << 3)
#define STT_PROTO_TYPES		(STT_PROTO_IPV4 | STT_PROTO_TCP)
struct stthdr {
	__u8		version;
	__u8		flags;
	__u8		l4_offset;
	__u8		reserved;
	__be16		mss;
	__be16		vlan_tci;
	/* This is the end of the first cacheline in most situations.  It's
	 * based on the assumption that cachelines are 64 bytes in length and
	 * the NIC is not doing header splitting.  If header splitting is
	 * taking place, then the cacheline starts at beginning of this struct.
	 */
	__be64		key;
};

static struct stthdr *stt_hdr(const struct sk_buff *skb)
{
	return (struct stthdr *)(skb_transport_header(skb) + tcp_hdrlen(skb));
}

/* struct stt_net - Per-Network namespace data for STT
 * @stt_fake_socket: Socket for STT port.
 * @n_tunnels: Number of STT tunnels present in given netns.
 **/
struct stt_net {
	struct socket *stt_fake_socket;
	int n_tunnels;
};

static int stt_net_id __read_mostly;

/* The length and offset of a fragment are encoded in the sequence number.
 * STT_SEQ_LEN_SHIFT is the left shift needed to store the length.
 * STT_SEQ_OFFSET_MASK is the mask to extract the offset.
 */
#define STT_SEQ_LEN_SHIFT 16
#define STT_SEQ_OFFSET_MASK ((1 << STT_SEQ_LEN_SHIFT) - 1)

/* The maximum amount of memory used to store packets waiting to be reassembled
 * on a given CPU.  Once this threshold is exceeded we will begin freeing the
 * least recently used fragments.
 */
#define REASM_HI_THRESH (4 * 1024 * 1024)
/* The target for the high memory evictor.  Once we have exceeded
 * REASM_HI_THRESH, we will continue freeing fragments until we hit
 * this limit.
 */
#define REASM_LO_THRESH (3 * 1024 * 1024)
/* The length of time a given packet has to be reassembled from the time the
 * first fragment arrives.  Once this limit is exceeded it becomes available
 * for cleaning.
 */
#define FRAG_EXP_TIME (30 * HZ)
/* Number of hash entries.  Each entry has only a single slot to hold a packet
 * so if there are collisions, we will drop packets.  This is allocated
 * per-cpu and each entry consists of struct pkt_frag.
 */
#define FRAG_HASH_SHIFT 8
#define FRAG_HASH_ENTRIES (1u << FRAG_HASH_SHIFT)
#define FRAG_HASH_SEGS ((sizeof(u32) * 8) / FRAG_HASH_SHIFT)
/* Maximum number of borrowed pages on each CPU that we will keep track of to
 * free later.
 */
#define PAGE_ENTRIES 4096
/* Number of oldest entries to look at before concluding that we're wasting our
 * time.
 */
#define PAGE_LRU_DEPTH 16
/* Time to wait before expecting that a stored page should be free. */
#define PAGE_CHK_TIME (1 * HZ)
/* The amount of time to wait for borrowed memory to be released by the
 * receiver of the packet when unloading the module.  There is a single timeout
 * for all borrowed pages, not one for each unreleased block.  A time of 0 means
 * wait forever.
 */
#define PAGE_RELEASE_WAIT (2 * HZ)
/* The period for running the cleaner.  Once every interval, the cleaner will
 * free all expired fragments and held pages.
 */
#define CLEAN_PERCPU_INTERVAL (30 * HZ)

struct pkt_key {
	__be32 saddr;
	__be32 daddr;
	__be32 pkt_seq;
};

struct pkt_frag {
	struct sk_buff *skbs;
	unsigned long timestamp;
	struct list_head lru_node;
	struct pkt_key key;
};

struct stt_percpu {
	struct flex_array *page_entries;
	unsigned long page_timestamp;
	unsigned short page_idx;

	struct flex_array *frag_hash;
	struct list_head frag_lru;
	unsigned int frag_mem_used;

	spinlock_t lock;
};

struct first_frag {
	struct sk_buff *last_skb;
	unsigned int mem_used;
	u16 tot_len;
	u16 rcvd_len;
	bool ecn_ce;
	bool ipsec;
};

struct frag_skb_cb {
	u16 offset;

	/* Only valid for the first skb in the chain. */
	struct first_frag first;
};
#define FRAG_CB(skb) ((struct frag_skb_cb *)(skb)->cb)

static struct stt_percpu __percpu *stt_percpu_data __read_mostly;
static u32 frag_hash_seed __read_mostly;

static void clean_percpu(struct work_struct *work);
static DECLARE_DELAYED_WORK(clean_percpu_wq, clean_percpu);

static int n_tunnels;
static DEFINE_PER_CPU(u32, pkt_seq_counter);

static int unclone_skb(struct sk_buff *skb)
{
	if (skb_cloned(skb))
		return pskb_expand_head(skb, 0, 0, GFP_ATOMIC);

	return 0;
}

static int clear_gso(struct sk_buff *skb)
{
	struct skb_shared_info *shinfo = skb_shinfo(skb);
	int err;

	if (shinfo->gso_type == 0 && shinfo->gso_size == 0 &&
	    shinfo->gso_segs == 0)
		return 0;

	err = unclone_skb(skb);
	if (unlikely(err))
		return err;

	shinfo = skb_shinfo(skb);
	shinfo->gso_type = 0;
	shinfo->gso_size = 0;
	shinfo->gso_segs = 0;

	return 0;
}

static struct sk_buff *normalize_frag_list(struct sk_buff *head,
					   struct sk_buff **skbp)
{
	struct sk_buff *skb = *skbp;
	struct sk_buff *last;

	do {
		struct sk_buff *frags;

		if (skb_shared(skb)) {
			struct sk_buff *nskb = skb_clone(skb, GFP_ATOMIC);
			if (unlikely(!nskb))
				return ERR_PTR(-ENOMEM);

			nskb->next = skb->next;
			consume_skb(skb);
			skb = nskb;
			*skbp = skb;
		}

		if (head) {
			head->len -= skb->len;
			head->data_len -= skb->len;
			head->truesize -= skb->truesize;
		}

		frags = skb_shinfo(skb)->frag_list;
		if (frags) {
			int err;

			err = unclone_skb(skb);
			if (unlikely(err))
				return ERR_PTR(err);

			last = normalize_frag_list(skb, &frags);
			if (IS_ERR(last))
				return last;

			skb_shinfo(skb)->frag_list = NULL;
			last->next = skb->next;
			skb->next = frags;
		} else {
			last = skb;
		}

		skbp = &skb->next;
	} while ((skb = skb->next));

	return last;
}

/* Takes a linked list of skbs, which potentially contain frag_list
 * (whose members in turn potentially contain frag_lists, etc.) and
 * converts them into a single linear linked list.
 */
static int straighten_frag_list(struct sk_buff **skbp)
{
	struct sk_buff *err_skb;

	err_skb = normalize_frag_list(NULL, skbp);
	if (IS_ERR(err_skb))
		return PTR_ERR(err_skb);

	return 0;
}

static void copy_skb_metadata(struct sk_buff *to, struct sk_buff *from)
{
	to->tstamp = from->tstamp;
	to->priority = from->priority;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
	to->mark = from->mark;
#elif defined(CONFIG_NETFILTER)
	to->nfmark = from->nfmark;
#endif
	skb_copy_secmark(to, from);
}


#ifndef SKIP_ZERO_COPY
static bool borrow_page(struct stt_percpu *stt_percpu, struct sk_buff *skb,
			skb_frag_t *frag)
{
	struct page *page = virt_to_page(skb->data);
	struct sk_buff **entryp;
	int i;

	if (unlikely(PageCompound(page)))
		return false;

	if (offset_in_page(skb->data) + skb_headlen(skb) > PAGE_SIZE)
		return false;

	for (i = 0; i < PAGE_LRU_DEPTH; i++) {
		struct sk_buff *entry;

		stt_percpu->page_idx = (stt_percpu->page_idx + 1) &
					(PAGE_ENTRIES - 1);

		entryp = flex_array_get(stt_percpu->page_entries,
				       stt_percpu->page_idx);
		entry = *entryp;

		if (!entry)
			break;
		if (page_count(virt_to_page(entry->data)) == 1) {
			consume_skb(entry);
			break;
		}
	}

	if (i == PAGE_LRU_DEPTH)
		return false;

	*entryp = skb;
	stt_percpu->page_timestamp = jiffies;

	__skb_frag_set_page(frag, page);
	skb_frag_size_set(frag, skb_headlen(skb));
	frag->page_offset = offset_in_page(skb->data);
	__skb_frag_ref(frag);

	return true;
}

/* Attempt to merge paged data into as few skbs as possible.  Any
 * remaining packets that can't be combined here will be linked using
 * a frag_list afterwards.  frag_lists cause a number of problems
 * when we try to output them, so later on we break them apart into
 * separate packets.  Therefore, by merging skbs as aggressively as
 * possible here we can cut down on the amount of processing later.
 * We'll hit this case with NICs that implement header splitting
 * because they'll put the outer Ethernet/IP/TCP headers in the
 * linear data area and the rest in frags.  With those cards, we'll
 * always be able to perform this optimization because we've already
 * stripped off the TCP header and are left with only paged data.
 */
static int merge_frags(struct sk_buff **headp, struct stt_percpu *stt_percpu)
{
	struct sk_buff *head = *headp;
	struct sk_buff *rskb;
	struct skb_shared_info *rskb_info;
	struct sk_buff *skb;
	struct sk_buff *nskb;
	unsigned int min_headroom;

	/* GRO can produce skbs with only the headers, which we've
	 * already pulled off.  We can just dump them.
	 */
	while (head->len == 0) {
		nskb = head->next;
		copy_skb_metadata(nskb, head);
		consume_skb(head);
		head = nskb;
	}
	*headp = head;

	rskb = head;
	rskb_info = skb_shinfo(head);
	min_headroom = skb_headroom(head);
	for (skb = head->next; skb; skb = nskb) {
		struct skb_shared_info *skb_info = skb_shinfo(skb);
		int nr_frags;
		skb_frag_t *rskb_frag, *skb_frag;
		int i;
		int head_frag = skb_headlen(skb) != 0 ? 1 : 0;

		nskb = skb->next;

		if (skb->len == 0) {
			rskb->next = skb->next;
			consume_skb(skb);
			continue;
		}

		if (skb_headroom(skb) < min_headroom)
			min_headroom = skb_headroom(skb);

		/* Depending on how the fragment was received, the amount of
		 * headroom can vary quite a bit.  Packets that weren't merged
		 * together later need to be split apart, which might mean a
		 * realloc if there isn't enough headroom.  The primary cause of
		 * not being able to merge packets is running out of space for
		 * the frags and that boundary falls randomly depending on the
		 * layout of the packets we receive.  We can leave this less to
		 * chance by deliberately cutting the list if we've already
		 * merged a large number of packets and the current one has a
		 * lot of headroom.
		 */
		if (rskb_info->nr_frags > MAX_SKB_FRAGS / 2 &&
		    min_headroom < 72 && skb_headroom(skb) > 96)
			goto next;

		nr_frags = rskb_info->nr_frags + head_frag + skb_info->nr_frags;
		if (nr_frags > MAX_SKB_FRAGS)
			goto next;

		if (unlikely(unclone_skb(rskb)))
			return -ENOMEM;
		rskb_info = skb_shinfo(rskb);

		rskb_frag = rskb_info->frags + rskb_info->nr_frags;
		skb_frag = skb_info->frags;

		if (head_frag &&
		    unlikely(!borrow_page(stt_percpu, skb, &rskb_frag[0])))
			goto next;

		for (i = 0; i < skb_info->nr_frags; i++) {
			rskb_frag[head_frag + i] = skb_frag[i];
			if (skb_cloned(skb))
				skb_frag_ref(rskb, head_frag + i);
		}

		rskb_info->nr_frags = nr_frags;
		rskb->len += skb->len;
		rskb->data_len += skb->len;
		rskb->truesize += skb->len;
		rskb->next = skb->next;

		if (!skb_cloned(skb))
			skb_info->nr_frags = 0;

		if (!head_frag)
			consume_skb(skb);

		continue;
next:
		rskb = skb;
		rskb_info = skb_info;
	}

	return 0;
}
#endif

static int __coalesce_skb_list(struct sk_buff **headp,
			       struct stt_percpu *stt_percpu)
{
	struct sk_buff *head, *frag;
	int err;

	err = straighten_frag_list(headp);
	if (unlikely(err))
		return err;

#ifndef SKIP_ZERO_COPY
	err = merge_frags(headp, stt_percpu);
	if (unlikely(err))
		return err;
#endif

	head = *headp;
	if (!head->next)
		return 0;

	for (frag = head->next; frag; frag = frag->next) {
		head->len += frag->len;
		head->data_len += frag->len;
		head->truesize += frag->truesize;
	}

	err = unclone_skb(head);
	if (unlikely(err))
		return err;

	skb_shinfo(head)->frag_list = head->next;
	head->next = NULL;

#ifdef SKIP_ZERO_COPY
	if (skb_shinfo(head)->frag_list) {
		err = __skb_linearize(head);
		if (err)
			return err;
	}
#endif
	return 0;
}

static int coalesce_skb_list(struct sk_buff **skbp)
{
	struct stt_percpu *stt_percpu;
	int err;

	stt_percpu = per_cpu_ptr(stt_percpu_data, smp_processor_id());

	spin_lock(&stt_percpu->lock);
	err = __coalesce_skb_list(skbp, stt_percpu);
	spin_unlock(&stt_percpu->lock);

	return err;
}

static int stt_hdr_len(const struct tnl_mutable_config *mutable)
{
	return sizeof(struct tcphdr) + sizeof(struct stthdr) + STT_ETH_PAD;
}

static bool stt_can_offload(const struct tnl_mutable_config *mutable,
			    struct sk_buff *skb)
{
	struct ethhdr *eh = eth_hdr(skb);
	u8 nw_proto = OVS_CB(skb)->flow->key.ip.proto;

	if (skb_is_gso(skb) && get_ip_summed(skb) != OVS_CSUM_PARTIAL) {
		int csum_offset;
		int len;
		__sum16 *csum;

		if (nw_proto == IPPROTO_TCP)
			csum_offset = offsetof(struct tcphdr, check);
		else if (nw_proto == IPPROTO_UDP)
			csum_offset = offsetof(struct udphdr, check);
		else
			return false;

		len = skb->len - skb_transport_offset(skb);
		csum = (__sum16 *)(skb_transport_header(skb) + csum_offset);

		if (eh->h_proto == htons(ETH_P_IP)) {
			struct iphdr *iph = ip_hdr(skb);
			*csum = ~csum_tcpudp_magic(iph->saddr, iph->daddr,
						   len, nw_proto, 0);
		} else if (eh->h_proto == htons(ETH_P_IPV6)) {
			struct ipv6hdr *ip6h = ipv6_hdr(skb);
			*csum = ~csum_ipv6_magic(&ip6h->saddr, &ip6h->daddr,
						 len, nw_proto, 0);
		} else {
			return false;
		}
		set_skb_csum_pointers(skb,
				      skb_transport_header(skb) - skb->head,
				      csum_offset);
		set_ip_summed(skb, OVS_CSUM_PARTIAL);
	}

	if (get_ip_summed(skb) == OVS_CSUM_PARTIAL) {
		u16 csum_start, csum_offset;

		/* Assume receiver can only offload TCP/UDP over IPv4/6,
		 * and require 802.1Q VLANs to be accelerated. */
		if (eh->h_proto != htons(ETH_P_IP) &&
		    eh->h_proto != htons(ETH_P_IPV6))
			return false;
		if (nw_proto != IPPROTO_TCP && nw_proto != IPPROTO_UDP)
			return false;

		/* L4 offset must fit in a 1-byte field. */
		get_skb_csum_pointers(skb, &csum_start, &csum_offset);
		if (csum_start - skb_headroom(skb) > 255)
			return false;

		if (skb_shinfo(skb)->gso_type & SKB_GSO_TCP_ECN)
			return false;
	}

	/* Total size of encapsulated packet must fit in 16 bits. */
	if (skb->len + mutable->tunnel_hlen > 65535)
		return false;

	return true;
}

static void stt_build_header(const struct vport *vport,
			     const struct tnl_mutable_config *mutable,
			     void *header)
{
	struct tcphdr *tcph = header;
	int stt_hlen = mutable->tunnel_hlen - sizeof(struct iphdr);
	int tcp_hlen = stt_hlen - sizeof(struct stthdr) - STT_ETH_PAD;
	struct stthdr *stth = (struct stthdr *)(header + tcp_hlen);

	memset(header, 0, stt_hlen);

	tcph->dest		= htons(STT_DST_PORT);
	tcph->doff		= tcp_hlen >> 2;
	tcph->ack		= 1;
	tcph->psh		= 1;
	tcph->window		= htons(USHRT_MAX);

	put_unaligned(mutable->out_key, &stth->key);
}

static __be16 get_src_port(const struct sk_buff *skb,
			   const struct tnl_mutable_config *mutable)
{
	if (mutable->flags & TNL_F_IPSEC)
		return htons(STT_IPSEC_SRC_PORT);

	/* Convert hash into a port between 32768 and 65535. */
	return (__force __be16)OVS_CB(skb)->flow->hash | htons(32768);
}

static __be32 ack_seq(void)
{
#if NR_CPUS <= 65536
	u32 *pkt_seq, ack;

	pkt_seq = &__get_cpu_var(pkt_seq_counter);
	ack = *pkt_seq << ilog2(NR_CPUS) | smp_processor_id();
	(*pkt_seq)++;

	return (__force __be32)ack;
#else
#error "Support for greater than 64k CPUs not implemented"
#endif
}

static struct sk_buff *stt_update_header(const struct vport *vport,
					 const struct tnl_mutable_config *mutable,
					 struct dst_entry *dst,
					 struct sk_buff *skb)
{
	struct iphdr *iph = ip_hdr(skb);
	struct tcphdr *tcph = tcp_hdr(skb);
	struct stthdr *stth = stt_hdr(skb);
	int tcp_hlen = tcp_hdrlen(skb);
	int data_len = skb->len - skb_transport_offset(skb) - tcp_hlen;
	u16 csum_start, csum_offset;
	unsigned short encap_mss;

	if (get_ip_summed(skb) == OVS_CSUM_PARTIAL) {
		stth->flags |= STT_CSUM_PARTIAL;

		get_skb_csum_pointers(skb, &csum_start, &csum_offset);
		stth->l4_offset = csum_start -
					(skb_headroom(skb) +
					skb_network_offset(skb) +
					mutable->tunnel_hlen);

		if (skb->protocol == htons(ETH_P_IP))
			stth->flags |= STT_PROTO_IPV4;

		if (OVS_CB(skb)->flow->key.ip.proto == IPPROTO_TCP)
			stth->flags |= STT_PROTO_TCP;

		stth->mss = htons(skb_shinfo(skb)->gso_size);
	} else if (get_ip_summed(skb) == OVS_CSUM_UNNECESSARY) {
		stth->flags |= STT_CSUM_VERIFIED;
	}

	stth->vlan_tci = htons(vlan_get_tci(skb));
	vlan_set_tci(skb, 0);

	if (mutable->flags & TNL_F_OUT_KEY_ACTION)
		put_unaligned(OVS_CB(skb)->tun_id, &stth->key);

	tcph->source = get_src_port(skb, mutable);
	tcph->seq = htonl(data_len << STT_SEQ_LEN_SHIFT);
	tcph->ack_seq = ack_seq();
	tcph->check = ~tcp_v4_check(skb->len - skb_transport_offset(skb),
				    iph->saddr, iph->daddr, 0);

	set_ip_summed(skb, OVS_CSUM_PARTIAL);
	set_skb_csum_pointers(skb, skb_transport_header(skb) - skb->head,
				offsetof(struct tcphdr, check));

	/* In theory coalesce_skb_list() can change skb and we don't
	 * update all of the appropriate fields.  However, in practice that
	 * can't happen because we'll never pass a skb with zero size
	 * first fragment (as we just added the tunnel headers).
	 */
	if (skb_shinfo(skb)->frag_list && unlikely(coalesce_skb_list(&skb)))
		goto error;

	encap_mss = dst_mtu(dst) - sizeof(struct iphdr) - tcp_hlen;
	if (data_len > encap_mss) {
		/* It's pretty rare to hit this case, so just fall back to
		 * linearizing for now.
		 */
		if (skb_shinfo(skb)->frag_list &&
		    unlikely(__skb_linearize(skb)))
			goto error;

		if (unlikely(unclone_skb(skb)))
			goto error;

		skb_shinfo(skb)->gso_type = SKB_GSO_TCPV4;
		skb_shinfo(skb)->gso_size = encap_mss;
		skb_shinfo(skb)->gso_segs = DIV_ROUND_UP(data_len, encap_mss);
	} else {
		if (unlikely(clear_gso(skb)))
			goto error;
	}

	forward_ip_summed(skb, true);

	return skb;

error:
	kfree_skb(skb);
	return NULL;
}

static void free_frag(struct stt_percpu *stt_percpu,
		      struct pkt_frag *frag)
{
	stt_percpu->frag_mem_used -= FRAG_CB(frag->skbs)->first.mem_used;
	ovs_tnl_free_linked_skbs(frag->skbs);
	list_del(&frag->lru_node);
	frag->skbs = NULL;
}

static void evict_frags(struct stt_percpu *stt_percpu)
{
	while (!list_empty(&stt_percpu->frag_lru) &&
	       stt_percpu->frag_mem_used > REASM_LO_THRESH) {
		struct pkt_frag *frag = list_first_entry(&stt_percpu->frag_lru,
							 struct pkt_frag,
							 lru_node);
		free_frag(stt_percpu, frag);
	}
}

static void schedule_clean_percpu(void)
{
	schedule_delayed_work(&clean_percpu_wq, CLEAN_PERCPU_INTERVAL);
}

static void clean_percpu(struct work_struct *work)
{
	int i;

	schedule_clean_percpu();

	for_each_possible_cpu(i) {
		struct stt_percpu *stt_percpu = per_cpu_ptr(stt_percpu_data, i);
		int j;

		for (j = 0; j < FRAG_HASH_ENTRIES; j++) {
			struct pkt_frag *frag = flex_array_get(stt_percpu->frag_hash, j);

			if (!frag->skbs ||
			    time_before(jiffies, frag->timestamp + FRAG_EXP_TIME))
				continue;

			spin_lock_bh(&stt_percpu->lock);

			if (frag->skbs &&
			    time_after(jiffies, frag->timestamp + FRAG_EXP_TIME))
				free_frag(stt_percpu, frag);

			spin_unlock_bh(&stt_percpu->lock);
		}

		if (time_before(jiffies, stt_percpu->page_timestamp +
					 PAGE_CHK_TIME))
			continue;

		for (j = 0; j < PAGE_ENTRIES; j++) {
			struct sk_buff **entryp = flex_array_get(stt_percpu->page_entries, j);
			struct sk_buff *entry = *entryp;

			if (!entry)
				continue;

			spin_lock_bh(&stt_percpu->lock);

			if (entry &&
			    page_count(virt_to_page(entry->data)) == 1) {
				consume_skb(entry);
				*entryp = NULL;
			}

			spin_unlock_bh(&stt_percpu->lock);
		}
	}
}

static bool validate_checksum(struct sk_buff *skb)
{
	struct iphdr *iph = ip_hdr(skb);

	if (skb_csum_unnecessary(skb))
		return true;

	if (skb->ip_summed == CHECKSUM_COMPLETE &&
	    !tcp_v4_check(skb->len, iph->saddr, iph->daddr, skb->csum))
		return true;

	skb->csum = csum_tcpudp_nofold(iph->saddr, iph->daddr, skb->len,
				       IPPROTO_TCP, 0);

	return __tcp_checksum_complete(skb) == 0;
}

static bool pkt_key_match(struct net *net,
			  const struct pkt_frag *a, const struct pkt_key *b)
{
	return a->key.saddr == b->saddr && a->key.daddr == b->daddr &&
	       a->key.pkt_seq == b->pkt_seq && net_eq(dev_net(a->skbs->dev), net);
}

static u32 pkt_key_hash(const struct net *net, const struct pkt_key *key)
{
	return jhash_3words((__force u32)key->saddr, (__force u32)key->daddr,
			    (__force u32)key->pkt_seq,
			    frag_hash_seed ^ (u32) (unsigned long) net);
}

static struct pkt_frag *lookup_frag(struct net *net, struct stt_percpu *stt_percpu,
				    const struct pkt_key *key, u32 hash)
{
	struct pkt_frag *frag, *victim_frag = NULL;
	int i;

	for (i = 0; i < FRAG_HASH_SEGS; i++) {
		frag = flex_array_get(stt_percpu->frag_hash,
				      hash & (FRAG_HASH_ENTRIES - 1));

		if (frag->skbs &&
		    time_before(jiffies, frag->timestamp + FRAG_EXP_TIME) &&
		    pkt_key_match(net, frag, key))
			return frag;

		if (!victim_frag || (victim_frag->skbs &&
		    (!frag->skbs ||
		     time_before(frag->timestamp, victim_frag->timestamp))))
			victim_frag = frag;

		hash >>= FRAG_HASH_SHIFT;
	}

	if (victim_frag->skbs)
		free_frag(stt_percpu, victim_frag);

	return victim_frag;
}

static bool sec_path_esp(struct sk_buff *skb)
{
	struct sec_path *sp = skb_sec_path(skb);

	if (sp) {
		int i;

		for (i = 0; i < sp->len; i++)
			if (sp->xvec[i]->id.proto == XFRM_PROTO_ESP)
				return true;
	}

	return false;
}

static struct sk_buff *reassemble(struct sk_buff *skb, u8 *tos, bool *ipsec)
{
	struct iphdr *iph = ip_hdr(skb);
	struct tcphdr *tcph = tcp_hdr(skb);
	u32 seq = ntohl(tcp_hdr(skb)->seq);
	int tot_len;
	struct pkt_key key;
	struct stt_percpu *stt_percpu;
	u32 hash;
	struct pkt_frag *frag;
	struct sk_buff *last_skb;

	tot_len = seq >> STT_SEQ_LEN_SHIFT;
	FRAG_CB(skb)->offset = seq & STT_SEQ_OFFSET_MASK;

	if (unlikely(skb->len == 0))
		goto out_free;

	if (unlikely(FRAG_CB(skb)->offset + skb->len > tot_len))
		goto out_free;

	if (tot_len == skb->len) {
		*ipsec = sec_path_esp(skb);

		if (skb_shinfo(skb)->frag_list &&
		    unlikely(coalesce_skb_list(&skb)))
			goto out_free;

		goto out;
	}

	key.saddr = iph->saddr;
	key.daddr = iph->daddr;
	key.pkt_seq = tcph->ack_seq;
	hash = pkt_key_hash(dev_net(skb->dev), &key);

	stt_percpu = per_cpu_ptr(stt_percpu_data, smp_processor_id());

	spin_lock(&stt_percpu->lock);

	if (unlikely(stt_percpu->frag_mem_used + skb->truesize > REASM_HI_THRESH))
		evict_frags(stt_percpu);

	frag = lookup_frag(dev_net(skb->dev), stt_percpu, &key, hash);

	if (!frag->skbs) {
		frag->skbs = skb;
		frag->key = key;
		frag->timestamp = jiffies;
		FRAG_CB(skb)->first.last_skb = skb;
		FRAG_CB(skb)->first.mem_used = skb->truesize;
		FRAG_CB(skb)->first.tot_len = tot_len;
		FRAG_CB(skb)->first.rcvd_len = skb->len;
		FRAG_CB(skb)->first.ecn_ce = INET_ECN_is_ce(iph->tos);
		FRAG_CB(skb)->first.ipsec = sec_path_esp(skb);
		list_add_tail(&frag->lru_node, &stt_percpu->frag_lru);
		stt_percpu->frag_mem_used += skb->truesize;

		skb = NULL;
		goto unlock;
	}

	/* Optimize for the common case where fragments are received in-order
	 * and not overlapping.
	 */
	last_skb = FRAG_CB(frag->skbs)->first.last_skb;
	if (likely(FRAG_CB(last_skb)->offset + last_skb->len ==
		   FRAG_CB(skb)->offset)) {
		last_skb->next = skb;
		FRAG_CB(frag->skbs)->first.last_skb = skb;
	} else {
		struct sk_buff *prev = NULL, *next;

		for (next = frag->skbs; next != NULL; next = next->next) {
			if (FRAG_CB(next)->offset >= FRAG_CB(skb)->offset)
				break;
			prev = next;
		}

		/* Overlapping fragments aren't allowed.  We shouldn't start
		 * before the end of the previous fragment.
		 */
		if (unlikely(prev &&
		      FRAG_CB(prev)->offset + prev->len > FRAG_CB(skb)->offset))
			goto unlock_free;

		/* We also shouldn't end after the beginning of the next
		 * fragment.
		 */
		if (unlikely(next &&
		      FRAG_CB(skb)->offset + skb->len > FRAG_CB(next)->offset))
			goto unlock_free;

		if (prev) {
			prev->next = skb;
		} else {
			FRAG_CB(skb)->first = FRAG_CB(frag->skbs)->first;
			frag->skbs = skb;
		}

		if (next)
			skb->next = next;
		else
			FRAG_CB(frag->skbs)->first.last_skb = skb;
	}

	FRAG_CB(frag->skbs)->first.ipsec &= sec_path_esp(skb);
	FRAG_CB(frag->skbs)->first.ecn_ce |= INET_ECN_is_ce(iph->tos);
	FRAG_CB(frag->skbs)->first.rcvd_len += skb->len;
	FRAG_CB(frag->skbs)->first.mem_used += skb->truesize;
	stt_percpu->frag_mem_used += skb->truesize;

	if (FRAG_CB(frag->skbs)->first.tot_len ==
	    FRAG_CB(frag->skbs)->first.rcvd_len) {
		struct sk_buff *frag_head = frag->skbs;
		int err;

		if (FRAG_CB(frag_head)->first.ecn_ce)
			*tos |= INET_ECN_CE;
		*ipsec = FRAG_CB(frag->skbs)->first.ipsec;
		frag_head->tstamp = skb->tstamp;

		list_del(&frag->lru_node);
		stt_percpu->frag_mem_used -= FRAG_CB(frag_head)->first.mem_used;
		frag->skbs = NULL;

		err = __coalesce_skb_list(&frag_head, stt_percpu);
		if (likely(!err)) {
			skb = frag_head;
		} else {
			ovs_tnl_free_linked_skbs(frag_head);
			skb = NULL;
		}
	} else {
		list_move_tail(&frag->lru_node, &stt_percpu->frag_lru);
		skb = NULL;
	}

	goto unlock;

unlock_free:
	kfree_skb(skb);
	skb = NULL;
unlock:
	spin_unlock(&stt_percpu->lock);
	return skb;
out_free:
	kfree_skb(skb);
	skb = NULL;
out:
	return skb;
}

static struct sk_buff *decapsulate(struct sk_buff *skb, u8 *tos, bool *ipsec)
{
	if (unlikely(!pskb_pull(skb, tcp_hdrlen(skb))))
		return NULL;

	skb = reassemble(skb, tos, ipsec);
	if (skb) {
		if (unlikely(!pskb_may_pull(skb, sizeof(struct stthdr) +
					    STT_ETH_PAD + ETH_HLEN))) {
			kfree_skb(skb);
			return NULL;
		}

		__skb_pull(skb, sizeof(struct stthdr) + STT_ETH_PAD);
	}

	return skb;
}

static bool set_offloads(struct sk_buff *skb)
{
	struct stthdr *stth = stt_hdr(skb);
	u8 proto_type;
	u16 csum_offset;
	unsigned short gso_type;
	int l3_header_size;
	int l4_header_size;

	vlan_set_tci(skb, ntohs(stth->vlan_tci));

	if (!(stth->flags & STT_CSUM_PARTIAL)) {
		if (stth->flags & STT_CSUM_VERIFIED)
			set_ip_summed(skb, OVS_CSUM_UNNECESSARY);
		else
			set_ip_summed(skb, OVS_CSUM_NONE);

		return clear_gso(skb) == 0;
	}

	proto_type = stth->flags & STT_PROTO_TYPES;

	if (proto_type == (STT_PROTO_IPV4 | STT_PROTO_TCP)) {
		/* TCP/IPv4 */
		csum_offset = offsetof(struct tcphdr, check);
		gso_type = SKB_GSO_TCPV4;
		l3_header_size = sizeof(struct iphdr);
		l4_header_size = sizeof(struct tcphdr);
	} else if (proto_type == STT_PROTO_TCP) {
		/* TCP/IPv6 */
		csum_offset = offsetof(struct tcphdr, check);
		gso_type = SKB_GSO_TCPV6;
		l3_header_size = sizeof(struct ipv6hdr);
		l4_header_size = sizeof(struct tcphdr);
	} else if (proto_type == STT_PROTO_IPV4) {
		/* UDP/IPv4 */
		csum_offset = offsetof(struct udphdr, check);
		gso_type = SKB_GSO_UDP;
		l3_header_size = sizeof(struct iphdr);
		l4_header_size = sizeof(struct udphdr);
	} else {
		/* UDP/IPv6 */
		csum_offset = offsetof(struct udphdr, check);
		gso_type = SKB_GSO_UDP;
		l3_header_size = sizeof(struct ipv6hdr);
		l4_header_size = sizeof(struct udphdr);
	}

	if (unlikely(stth->l4_offset < ETH_HLEN + l3_header_size))
		return false;

	if (unlikely(!pskb_may_pull(skb, stth->l4_offset + l4_header_size)))
		return false;
	stth = stt_hdr(skb);

	set_ip_summed(skb, OVS_CSUM_PARTIAL);
	set_skb_csum_pointers(skb, skb_headroom(skb) + stth->l4_offset,
				   csum_offset);

	if (stth->mss) {
		if (unlikely(unclone_skb(skb)))
			return false;

		skb_shinfo(skb)->gso_type = gso_type | SKB_GSO_DODGY;
		skb_shinfo(skb)->gso_size = ntohs(stth->mss);
		skb_shinfo(skb)->gso_segs = 0;
	} else {
		if (unlikely(clear_gso(skb)))
			return false;
	}

	return true;
}

static void update_seg_headers(struct sk_buff *skb, bool head,
				unsigned int l4_offset, unsigned int hdr_len,
				bool ipv4, u32 tcp_seq)
{
	u16 old_len, new_len;
	__be32 delta;
	struct tcphdr *tcph;
	int gso_size;

	if (ipv4) {
		struct iphdr *iph = (struct iphdr *)(skb->data + ETH_HLEN);
		old_len = ntohs(iph->tot_len);
		new_len = skb->len - ETH_HLEN;
		iph->tot_len = htons(new_len);

		ip_send_check(iph);
	} else {
		struct ipv6hdr *ip6h = (struct ipv6hdr *)(skb->data + ETH_HLEN);
		old_len = ntohs(ip6h->payload_len);
		new_len = skb->len - ETH_HLEN - sizeof(struct ipv6hdr);
		ip6h->payload_len = htons(new_len);
	}

	tcph = (struct tcphdr *)(skb->data + l4_offset);
	if (!head) {
		tcph->seq = htonl(tcp_seq);
		tcph->cwr = 0;
	}

	if (skb->next)
		tcph->fin = tcph->psh = 0;

	delta = htonl(~old_len + new_len);
	tcph->check = ~csum_fold((__force __wsum)((__force u32)tcph->check +
				 (__force u32)delta));

	gso_size = skb_shinfo(skb)->gso_size;
	if (gso_size && skb->len - hdr_len <= gso_size)
		BUG_ON(clear_gso(skb));
}

static int frags_segment(struct vport *vport, struct sk_buff **headp)
{
	struct sk_buff *head = *headp;
	struct stthdr *stth = stt_hdr(head);
	struct sk_buff *frag, *prev, *next;
	int hdr_len;
	u16 csum_start, csum_offset;
	bool ipv4;
	struct tcphdr *tcph;
	int tcp_len;
	int seg_len;
	u32 seq;
	bool head_skb;

	/* Realistically, no driver can handle frag_lists which forces
	 * software segmentation on large packets.  When handling
	 * frag_lists skb_segment() requires that the frags match the
	 * MSS, which we can't guarantee because there is an extra
	 * header in front of the first one.  Here we break up the
	 * frag_list into individual packets to completely avoid the
	 * problem.
	 */

	/* If no offloading is in use then we don't have enough information
	 * to process the headers.
	 */
	if (!(stth->flags & STT_CSUM_PARTIAL))
		goto linearize;

	/* Handling UDP packets requires IP fragmentation, which means that
	 * the L4 checksum can no longer be calculated by hardware (since the
	 * fragments are in different packets.  If we have to compute the
	 * checksum it's faster just to linearize and large UDP packets are
	 * pretty uncommon anyways, so it's not worth dealing with for now.
	 */
	if (!(stth->flags & STT_PROTO_TCP))
		goto linearize;

	if ((stth->flags & STT_PROTO_IPV4)) {
		struct iphdr *iph = (struct iphdr *)(head->data + ETH_HLEN);

		/* It's difficult to get the IP IDs exactly right here due to
		 * varying segment sizes and potentially multiple layers of
		 * segmentation.  IP ID isn't important when DF is set and DF
		 * is generally set for TCP packets, so just linearize if it's
		 * not.
		 */
		if (!(iph->frag_off & htons(IP_DF)))
			goto linearize;

		ipv4 = true;
	} else {
		struct ipv6hdr *ip6h = (struct ipv6hdr *)(head->data + ETH_HLEN);

		/* Jumbograms require more processing to update and we'll
		 * probably never see them, so just linearize.
		 */
		if (ip6h->payload_len == 0)
			goto linearize;

		ipv4 = false;
	}

	tcph = (struct tcphdr *)(head->data + stth->l4_offset);
	tcp_len = tcph->doff * 4;
	hdr_len = stth->l4_offset + tcp_len;

	if (unlikely(tcp_len < sizeof(struct tcphdr) ||
		     head->len < hdr_len))
		return -EINVAL;

	if (unlikely(!pskb_may_pull(head, hdr_len)))
		return -ENOMEM;
	stth = stt_hdr(head);

	if (!skb_shinfo(head)->frag_list)
		return 0;

	seg_len = skb_pagelen(head) - hdr_len;
	seq = ntohl(tcph->seq);

	/* See the comment under the call to update_seg_headers() for head
	 * for an explanation of why this can be zero.
	 */
	head_skb = seg_len == 0;

	get_skb_csum_pointers(head, &csum_start, &csum_offset);
	csum_start -= skb_headroom(head);

	frag = skb_shinfo(head)->frag_list;
	skb_shinfo(head)->frag_list = NULL;
	prev = head;
	do {
		next = frag->next;

		head->len -= frag->len;
		head->data_len -= frag->len;
		head->truesize -= frag->truesize;

		seq += seg_len;
		seg_len = frag->len;

		if (skb_cloned(frag) || skb_headroom(frag) < hdr_len) {
			int extra_head = hdr_len - skb_headroom(frag);

			if (unlikely(pskb_expand_head(frag,
					extra_head > 0 ? extra_head : 0, 0,
					GFP_ATOMIC))) {
				kfree_skb(frag);
				continue;
			}
		}

		memcpy(__skb_push(frag, hdr_len), head->data, hdr_len);

		set_ip_summed(frag, get_ip_summed(head));
		set_skb_csum_pointers(frag, skb_headroom(frag) + csum_start,
				      csum_offset);
		skb_shinfo(frag)->gso_size = skb_shinfo(head)->gso_size;
		skb_shinfo(frag)->gso_type = skb_shinfo(head)->gso_type;
		skb_shinfo(frag)->gso_segs = 0;

		copy_skb_metadata(frag, head);
		vlan_set_tci(frag, vlan_get_tci(head));
		OVS_CB(frag)->tun_id = OVS_CB(head)->tun_id;

		update_seg_headers(frag, head_skb, stth->l4_offset, hdr_len,
				   ipv4, seq);
		head_skb = false;

		frag->next = NULL;
		prev->next = frag;
		prev = frag;
	} while ((frag = next));

	if (head->len > hdr_len) {
		update_seg_headers(head, true, stth->l4_offset, hdr_len, ipv4, 0);
	} else {
		/* It's possible that the head segment consists only of
		 * headers, which provides no value and should just be dropped.
		 * This can occur if it was initially small (such as created
		 * by GRO) and we weren't able to merge any pages into it from
		 * later skbs.  When this happens, we pull the headers into it
		 * but no data.  This can only happen for the first segment
		 * because later ones start out as pure data with no headers and
		 * therefore can only be empty if they are zero length packets
		 * after decapsulation.  This is possible but we drop all such
		 * packets during the merging process.
		 */
		*headp = head->next;
		consume_skb(head);
	}

	return 0;

linearize:
	return __skb_linearize(head);
}

/* Different code paths use different methods for storing the truesize
 * of frag_lists in the head.  In some places it is the sum of the
 * truesizes of each fragment, in other cases it is the sum of the
 * lengths.  We use the former method consistently to ensure that our
 * internal packet counting adds up.  However, if a frag_list was
 * previously assembled using the other method and we broke it apart
 * the truesize can become negative.  As truesize is actually an
 * unsigned value, it becomes very large and socket receive buffers
 * are incorrectly filled up.  This function recomputes the correct
 * truesize before we pass the packet up.
 */
static void update_truesize(struct sk_buff *skb)
{
	skb->truesize = sizeof(struct sk_buff) +
			(skb_end_pointer(skb) - skb->head) +
			skb->data_len;
}

static void stt_rcv(struct sk_buff *skb)
{
	struct iphdr *iph;
	struct stthdr *stth;
	struct vport *vport;
	const struct tnl_mutable_config *mutable;
	bool ipsec = false;
	int tunnel_type;
	struct sk_buff *next;
	__be32 saddr, daddr;
	u8 tos;
	__be64 key;

	if (unlikely(!validate_checksum(skb)))
		goto error;

	/* Packets with the ECN-Echo bit set are control packets
	 * that should not be interpreted according to the normal
	 * STT reassembly rules.  Instead, these packets are used
	 * to elicit particalar behaviors from intermediate devices
	 * and should be treated as normal TCP.  Unknown packets
	 * should be dropped.  Currently no uses are defined.
	 */
	if (unlikely(tcp_hdr(skb)->ece))
		goto error;

	iph = ip_hdr(skb);
	saddr = iph->saddr;
	daddr = iph->daddr;
	tos = iph->tos;

	skb = decapsulate(skb, &tos, &ipsec);
	if (!skb)
		return;

	if (unlikely(stt_hdr(skb)->version != 0))
		goto error;

	if (unlikely(!set_offloads(skb)))
		goto error;

	stth = stt_hdr(skb);

	key = get_unaligned(&stth->key);

	tunnel_type = TNL_T_PROTO_STT;
	if (ipsec)
		tunnel_type |= TNL_T_IPSEC;

	vport = ovs_tnl_find_port(dev_net(skb->dev), daddr, saddr, key,
				  tunnel_type, &mutable);
	if (unlikely(!vport)) {
		icmp_send(skb, ICMP_DEST_UNREACH, ICMP_PORT_UNREACH, 0);
		goto error;
	}

	if (mutable->flags & TNL_F_IN_KEY_MATCH)
		OVS_CB(skb)->tun_id = key;
	else
		OVS_CB(skb)->tun_id = 0;

	if (skb_shinfo(skb)->frag_list && unlikely(frags_segment(vport, &skb)))
		goto error;

	do {
		next = skb->next;
		skb->next = NULL;
		update_truesize(skb);
		ovs_tnl_rcv(vport, skb, tos);
	} while ((skb = next));

	return;

error:
	kfree_skb(skb);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,24)
static unsigned int nf_ip_hook(unsigned int hooknum, struct sk_buff *skb,
			       const struct net_device *in,
			       const struct net_device *out,
			       int (*okfn)(struct sk_buff *))
{
#else
static unsigned int nf_ip_hook(unsigned int hooknum, struct sk_buff **skbp,
			       const struct net_device *in,
			       const struct net_device *out,
			       int (*okfn)(struct sk_buff *))
{
	struct sk_buff *skb = *skbp;
#endif
	int ip_hdr_len;
	struct stt_net *stt_net = net_generic(dev_net(skb->dev), stt_net_id);

	if (!stt_net->n_tunnels)
		return NF_ACCEPT;

	if (ip_hdr(skb)->protocol != IPPROTO_TCP)
		return NF_ACCEPT;

	ip_hdr_len = ip_hdrlen(skb);

	if (unlikely(!pskb_may_pull(skb, ip_hdr_len + sizeof(struct tcphdr))))
		return NF_ACCEPT;

	skb_set_transport_header(skb, ip_hdr_len);

	if (tcp_hdr(skb)->dest != htons(STT_DST_PORT))
		return NF_ACCEPT;

	__skb_pull(skb, ip_hdr_len);

	stt_rcv(skb);
	return NF_STOLEN;
}

static struct nf_hook_ops nf_hook_ops __read_mostly = {
	.hook		= nf_ip_hook,
	.owner		= THIS_MODULE,
	.pf		= NFPROTO_IPV4,
	.hooknum	= NF_INET_LOCAL_IN,
	.priority	= INT_MAX,
};

static const struct tnl_ops stt_tnl_ops = {
	.tunnel_type	= TNL_T_PROTO_STT,
	.ipproto	= IPPROTO_TCP,
	.vlan_offload	= true,
	.dport		= htons(STT_DST_PORT),
	.hdr_len	= stt_hdr_len,
	.build_header	= stt_build_header,
	.update_header	= stt_update_header,
	.can_offload	= stt_can_offload,
};

static const struct tnl_ops ipsec_stt_tnl_ops = {
	.tunnel_type	= TNL_T_PROTO_STT | TNL_T_IPSEC,
	.ipproto	= IPPROTO_TCP,
	.sport		= htons(STT_IPSEC_SRC_PORT),
	.dport		= htons(STT_DST_PORT),
	.vlan_offload	= true,
	.hdr_len	= stt_hdr_len,
	.build_header	= stt_build_header,
	.update_header	= stt_update_header,
	.can_offload	= stt_can_offload,
};

static int stt_create_socket(struct net *net)
{
	struct stt_net *stt_net = net_generic(net, stt_net_id);
	int err;
	struct sockaddr_in sin;

	if (stt_net->n_tunnels) {
		stt_net->n_tunnels++;
		return 0;
	}

	err = sock_create_kern(AF_INET, SOCK_STREAM, 0, &stt_net->stt_fake_socket);
	if (err)
		return err;

	/* release net ref. */
	sk_change_net(stt_net->stt_fake_socket->sk, net);

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_port = htons(STT_DST_PORT);

	err = kernel_bind(stt_net->stt_fake_socket, (struct sockaddr *)&sin,
			  sizeof(struct sockaddr_in));
	if (err) {
		sk_release_kernel(stt_net->stt_fake_socket->sk);
		goto out;
	}

	stt_net->n_tunnels++;
out:
	return err;
}

static void stt_release_socket(struct net *net)
{
	struct stt_net *stt_net = net_generic(net, stt_net_id);

	stt_net->n_tunnels--;
	if (stt_net->n_tunnels)
		return;

	sk_release_kernel(stt_net->stt_fake_socket->sk);
}

static int stt_start(void)
{
	int err;
	int i;

	if (n_tunnels) {
		n_tunnels++;
		return 0;
	}

	get_random_bytes(&frag_hash_seed, sizeof(u32));

	stt_percpu_data = alloc_percpu(struct stt_percpu);
	if (!stt_percpu_data) {
		err = -ENOMEM;
		goto error;
	}

	for_each_possible_cpu(i) {
		struct stt_percpu *stt_percpu = per_cpu_ptr(stt_percpu_data, i);

		spin_lock_init(&stt_percpu->lock);
		INIT_LIST_HEAD(&stt_percpu->frag_lru);
		get_random_bytes(&per_cpu(pkt_seq_counter, i), sizeof(u32));

		stt_percpu->frag_hash = flex_array_alloc(sizeof(struct pkt_frag),
							  FRAG_HASH_ENTRIES,
							  GFP_KERNEL | __GFP_ZERO);
		if (!stt_percpu->frag_hash) {
			err = -ENOMEM;
			goto free_percpu;
		}

		err = flex_array_prealloc(stt_percpu->frag_hash, 0,
					  FRAG_HASH_ENTRIES,
					  GFP_KERNEL | __GFP_ZERO);
		if (err)
			goto free_percpu;

		stt_percpu->page_entries = flex_array_alloc(sizeof(struct sk_buff *),
							     PAGE_ENTRIES,
							     GFP_KERNEL | __GFP_ZERO);
		if (!stt_percpu->page_entries) {
			err = -ENOMEM;
			goto free_percpu;
		}

		err = flex_array_prealloc(stt_percpu->page_entries, 0,
					  PAGE_ENTRIES,
					  GFP_KERNEL | __GFP_ZERO);
		if (err)
			goto free_percpu;
	}

	err = nf_register_hook(&nf_hook_ops);
	if (err)
		goto free_percpu;

	schedule_clean_percpu();

	n_tunnels++;
	return 0;

free_percpu:
	for_each_possible_cpu(i) {
		struct stt_percpu *stt_percpu = per_cpu_ptr(stt_percpu_data, i);
		if (stt_percpu->frag_hash)
			flex_array_free(stt_percpu->frag_hash);
		if (stt_percpu->page_entries)
			flex_array_free(stt_percpu->page_entries);
	}

	free_percpu(stt_percpu_data);

error:
	return err;
}

static int release_borrowed_pages(bool final)
{
	int i;
	int unreleased = 0;

	for_each_possible_cpu(i) {
		struct stt_percpu *stt_percpu = per_cpu_ptr(stt_percpu_data, i);
		int j;

		for (j = 0; j < PAGE_ENTRIES; j++) {
			struct sk_buff **entryp, *entry;

			entryp = flex_array_get(stt_percpu->page_entries, j);
			entry = *entryp;

			if (!entry)
				continue;

			if (page_count(virt_to_page(entry->data)) == 1) {
				consume_skb(entry);
				*entryp = NULL;
			} else {
				struct skb_shared_info *shinfo = skb_shinfo(entry);
				bool cloned = skb_cloned(entry);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,29)
				unreleased += ksize(entry->head);
#else
				unreleased += (skb_end_pointer(entry) -
					      entry->head) +
					      sizeof(struct skb_shared_info);
#endif
				if (cloned)
					unreleased += shinfo->nr_frags *
							PAGE_SIZE;

				if (final) {
					if (!cloned) {
						int k;
						for (k = 0; k < shinfo->nr_frags; k++)
							skb_frag_unref(entry, k);
						shinfo->nr_frags = 0;
					}

					/* This is the final try and we've
					 * failed.  If we bump the refcount it
					 * will prevent the still in-use memory
					 * from getting reclaimed while allowing
					 * all of the skb metadata to be
					 * released.
					 */
					atomic_inc(&shinfo->dataref);
					entry->cloned = 1;

					consume_skb(entry);
					*entryp = NULL;
				}
			}
		}
	}

	return unreleased;
}

static void stt_cleanup(void)
{
	int i;
	unsigned long release_start;
	int unreleased_mem;

	n_tunnels--;
	if (n_tunnels)
		return;

	cancel_delayed_work_sync(&clean_percpu_wq);
	nf_unregister_hook(&nf_hook_ops);

	release_start = jiffies;
	do {
		unreleased_mem = release_borrowed_pages(false);
		if (!unreleased_mem)
			break;
		msleep(100);
	} while (!PAGE_RELEASE_WAIT ||
		 time_before(jiffies, release_start + PAGE_RELEASE_WAIT));

	if (unreleased_mem) {
		unreleased_mem = release_borrowed_pages(true);
		if (unreleased_mem)
			pr_warn("unable to release %dk of borrowed memory\n",
				unreleased_mem / 1024);
	}

	for_each_possible_cpu(i) {
		struct stt_percpu *stt_percpu = per_cpu_ptr(stt_percpu_data, i);
		int j;

		for (j = 0; j < FRAG_HASH_ENTRIES; j++) {
			struct pkt_frag *frag = flex_array_get(stt_percpu->frag_hash, j);
			ovs_tnl_free_linked_skbs(frag->skbs);
		}

		flex_array_free(stt_percpu->frag_hash);
		flex_array_free(stt_percpu->page_entries);
	}

	free_percpu(stt_percpu_data);
}

static struct vport *stt_create(const struct vport_parms *parms)
{
	struct net *net = ovs_dp_get_net(parms->dp);
	int err;
	struct nlattr *flags_nlattr;
	struct vport *vport;

	flags_nlattr = nla_find_nested(parms->options, OVS_TUNNEL_ATTR_FLAGS);
	if (!flags_nlattr || nla_len(flags_nlattr) != sizeof(u32))
		return ERR_PTR(-EINVAL);

	err = stt_start();
	if (err)
		return ERR_PTR(err);

	err = stt_create_socket(net);
	if (err) {
		vport = ERR_PTR(err);
		goto err;
	}

	if (nla_get_u32(flags_nlattr) & TNL_F_IPSEC)
	    vport = ovs_tnl_create(parms, &ovs_stt_vport_ops, &ipsec_stt_tnl_ops);
	else
	    vport = ovs_tnl_create(parms, &ovs_stt_vport_ops, &stt_tnl_ops);

	if (IS_ERR(vport))
		goto err_sock;

	return vport;

err_sock:
	stt_release_socket(net);
err:
	stt_cleanup();
	return vport;
}

static void stt_destroy(struct vport *vport)
{
	ovs_tnl_destroy(vport);
	stt_release_socket(ovs_dp_get_net(vport->dp));
	stt_cleanup();
}

static struct pernet_operations stt_net_ops = {
	.id   = &stt_net_id,
	.size = sizeof(struct stt_net),
};

static int stt_init(void)
{
	return register_pernet_subsys(&stt_net_ops);
}

static void stt_exit(void)
{
	unregister_pernet_subsys(&stt_net_ops);
}

const struct vport_ops ovs_stt_vport_ops = {
	.type		= OVS_VPORT_TYPE_STT,
	.flags		= VPORT_F_TUN_ID,
	.init		= stt_init,
	.exit		= stt_exit,
	.create		= stt_create,
	.destroy	= stt_destroy,
	.set_addr	= ovs_tnl_set_addr,
	.get_name	= ovs_tnl_get_name,
	.get_addr	= ovs_tnl_get_addr,
	.get_options	= ovs_tnl_get_options,
	.set_options	= ovs_tnl_set_options,
	.get_dev_flags	= ovs_vport_gen_get_dev_flags,
	.is_running	= ovs_vport_gen_is_running,
	.get_operstate	= ovs_vport_gen_get_operstate,
	.send		= ovs_tnl_send,
};
#else
#warning STT tunneling will not be available on kernels without CONFIG_NETFILTER
#endif /* !CONFIG_NETFILTER */
