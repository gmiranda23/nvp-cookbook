/* Copyright (c) 2011 Nicira, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "epan/packet.h"
#include "epan/ipproto.h"
#include "epan/prefs.h"
#include "epan/reassemble.h"

#define STT_PORT 7471

static gboolean pref_disable = FALSE;
static gboolean pref_reassemble = TRUE;

static int proto_stt = -1;		/* STT protocol handle. */
static gint ett_stt = -1;		/* STT protocol details tree. */
static gint ett_stt_stt = -1;		/* Subtree of STT header details. */
static gint ett_stt_stt_flags = -1;	/* Subtree of STT header flags. */
static gint ett_segment = -1;		/* "Segment reassembled in PDU %d" subtree. */
static gint ett_segments = -1;		/* Reassembed segments subtree. */

static dissector_handle_t tcp_dissector = NULL;
static dissector_handle_t eth_dissector = NULL;
static dissector_handle_t data_dissector = NULL;

static GHashTable *frag_tbl = NULL;

/* STT protocol header fields in subtree view. */
/* Overloaded TCP header fields. */
static int hf_stream_id = -1;
static int hf_dport = -1;
static int hf_pkt_len = -1;
static int hf_seg_off = -1;
static int hf_pkt_id = -1;
static int hf_data_off = -1;
/* STT header fields. */
static int hf_version = -1;
static int hf_flags = -1;
static int hf_flag_csum_verified = -1;
static int hf_flag_csum_partial = -1;
static int hf_flag_proto_ipv4 = -1;
static int hf_flag_proto_tcp = -1;
static int hf_l4_offset = -1;
static int hf_mss = -1;
static int hf_vlan_tci = -1;
static int hf_key = -1;

/* Fragmentation subtree fields. */
static int hf_segments = -1;
static int hf_segment = -1;
static int hf_segment_overlap = -1;
static int hf_segment_overlap_conflict = -1;
static int hf_segment_multiple_tails = -1;
static int hf_segment_too_long_fragment = -1;
static int hf_segment_error = -1;
static int hf_reassembled_in = -1;
static int hf_reassembled_length = -1;

/* Offsets of overloaded TCP header fields. */
#define STT_TCP_OFF_STREAM_ID 0
#define STT_TCP_OFF_DPORT 2
#define STT_TCP_OFF_PKT_LEN 4
#define STT_TCP_OFF_SEG_OFF 6
#define STT_TCP_OFF_PKT_ID 8
#define STT_TCP_OFF_DATA_OFF 12

/* Lengths of overloaded TCP header fields. */
#define STT_TCP_LEN_STREAM_ID 2
#define STT_TCP_LEN_DPORT 2
#define STT_TCP_LEN_PKT_LEN 2
#define STT_TCP_LEN_SEG_OFF 2
#define STT_TCP_LEN_PKT_ID 4
#define STT_TCP_LEN_DATA_OFF 1

/* Length of entire overloaded TCP header. */
#define STT_TCP_HDR_LEN 20

/* Offsets of STT header fields. */
#define STT_OFF_VERSION 0
#define STT_OFF_FLAGS 1
#define STT_OFF_L4_OFFSET 2
#define STT_OFF_RESERVED 3
#define STT_OFF_MSS 4
#define STT_OFF_VLAN_TCI 6
#define STT_OFF_KEY 8

/* Lengths of STT header fields. */
#define STT_LEN_VERSION 1
#define STT_LEN_FLAGS 1
#define STT_LEN_L4_OFFSET 1
#define STT_LEN_RESERVED 1
#define STT_LEN_MSS 2
#define STT_LEN_VLAN_TCI 2
#define STT_LEN_KEY 8

/* Sum of STT header field sizes plus trailing padding. */
#define STT_HEADER_SIZE 18

/* STT header flag bit offsets. */
#define STT_FLAG_CSUM_VERIFIED	7
#define STT_FLAG_CSUM_PARTIAL	6
#define STT_FLAG_PROTO_IPV4	5
#define STT_FLAG_PROTO_TCP	4

#define STT_FLAGS_WIDTH		(STT_LEN_FLAGS * 8)	/* bits */

static const fragment_items frag_items = {
    &ett_segment,
    &ett_segments,
    &hf_segments,
    &hf_segment,
    &hf_segment_overlap,
    &hf_segment_overlap_conflict,
    &hf_segment_multiple_tails,
    &hf_segment_too_long_fragment,
    &hf_segment_error,
    &hf_reassembled_in,
    &hf_reassembled_length,
    "STT fragments"
};

static void
stt_segment_init(void)
{
    fragment_table_init(&frag_tbl);
}

static tvbuff_t *
handle_segment(tvbuff_t *tvb, packet_info *pinfo, proto_tree *tree,
               const guint16 pkt_len, guint16 seg_off,
               const guint16 data_off)
{
    fragment_data *frags;
    int offset;
    guint32 pkt_id, frag_data_len;
    gboolean more_frags, update_col_info;

    /* Skip fake TCP header after the first segment. */
    if (seg_off == 0) {
        offset = 0;
    } else {
        offset = data_off;
        /* We saved the TCP header on the first packet (only), which skews the
         * segment offset. */
        seg_off += STT_TCP_HDR_LEN;
    }

    pkt_id = tvb_get_ntohl(tvb, STT_TCP_OFF_PKT_ID);
    frag_data_len = tvb_length_remaining(tvb, offset);
    more_frags = seg_off + frag_data_len < pkt_len;

    /* The last fragment gets passed to the appropriate subdissector, which
     * fills out the info column in the packet list view. For other fragments,
     * display some useful information (otherwise they just show up as "IP").
     */
     col_set_str(pinfo->cinfo, COL_PROTOCOL, "STT");
     col_add_fstr(pinfo->cinfo, COL_INFO,
                  "STT segment (ID: %u, total len: %hu, seg off: %hu)",
                   pkt_id, pkt_len, seg_off);

    frags = fragment_add(tvb, offset, pinfo, pkt_id, frag_tbl, seg_off,
                         frag_data_len, more_frags);

    /* Update reassembly fields in UI if reassembly is complete. */
    if (frags) {
        return process_reassembled_data(tvb, offset, pinfo, "Reassembled STT",
                                    frags, &frag_items, &update_col_info, tree);
    }

    return NULL;
}

static void
dissect_stt_tree(tvbuff_t *tvb, proto_tree *tree, guint16 seg_off, guint8 data_off)
{
    static const guint encoding = FALSE;
    gint length = data_off;
    proto_item *ti;
    proto_tree *tcp_tree, *stt_tree, *flags_tree;

    if (seg_off == 0) {
        length += STT_HEADER_SIZE;
    }

    /* Add/populate subtree with fake TCP header details. */
    ti = proto_tree_add_item(tree, proto_stt, tvb, STT_TCP_OFF_STREAM_ID,
                             length, encoding);
    tcp_tree = proto_item_add_subtree(ti, ett_stt);

#define PROTO_TREE_ADD_ITEM_TCP(field, ucfield)         \
    proto_tree_add_item(tcp_tree, hf_##field, tvb,      \
                        STT_TCP_OFF_##ucfield,		\
                        STT_TCP_LEN_##ucfield,          \
                        encoding)

    PROTO_TREE_ADD_ITEM_TCP(stream_id, STREAM_ID);
    PROTO_TREE_ADD_ITEM_TCP(dport, DPORT);
    PROTO_TREE_ADD_ITEM_TCP(pkt_len, PKT_LEN);
    PROTO_TREE_ADD_ITEM_TCP(seg_off, SEG_OFF);
    PROTO_TREE_ADD_ITEM_TCP(pkt_id, PKT_ID);

#undef PROTO_TREE_ADD_ITEM_TCP

    proto_tree_add_uint_format_value(tcp_tree, hf_data_off, tvb,
                                     STT_TCP_OFF_DATA_OFF,
                                     STT_TCP_LEN_DATA_OFF,
                                     data_off,
                                     "%u", data_off);

    /* Add sub-subtree for STT header, if there is one. */
    if (seg_off == 0) {
        ti = proto_tree_add_item(tcp_tree, proto_stt, tvb, data_off,
                                 STT_HEADER_SIZE, encoding);
        stt_tree = proto_item_add_subtree(ti, ett_stt_stt);

#define PROTO_TREE_ADD_ITEM_STT(field, ucfield)                 \
        proto_tree_add_item(stt_tree, hf_##field, tvb,          \
                            data_off + STT_OFF_##ucfield,       \
                            STT_LEN_##ucfield,                  \
                            encoding)

        PROTO_TREE_ADD_ITEM_STT(version, VERSION);

        ti = proto_tree_add_item(stt_tree, hf_flags, tvb,
                                 data_off + STT_OFF_FLAGS,
                                 STT_LEN_FLAGS, encoding);
        flags_tree = proto_item_add_subtree(ti, ett_stt_stt_flags);

#define PROTO_TREE_ADD_FLAG_STT(flag, bit)                              \
        proto_tree_add_bits_item(flags_tree, hf_flag_##flag, tvb,       \
                                 (data_off + STT_OFF_FLAGS) * 8 + STT_FLAG_##bit, \
                                 STT_LEN_FLAGS, encoding)

        PROTO_TREE_ADD_FLAG_STT(csum_verified, CSUM_VERIFIED);
        PROTO_TREE_ADD_FLAG_STT(csum_partial, CSUM_PARTIAL);
        PROTO_TREE_ADD_FLAG_STT(proto_ipv4, PROTO_IPV4);
        PROTO_TREE_ADD_FLAG_STT(proto_tcp, PROTO_TCP);

#undef PROTO_TREE_ADD_FLAG_STT

        PROTO_TREE_ADD_ITEM_STT(l4_offset, L4_OFFSET);
        PROTO_TREE_ADD_ITEM_STT(mss, MSS);
        PROTO_TREE_ADD_ITEM_STT(vlan_tci, VLAN_TCI);
        PROTO_TREE_ADD_ITEM_STT(key, KEY);

#undef PROTO_TREE_ADD_ITEM_STT
    }
}

static void
dissect_stt(tvbuff_t *tvb, packet_info *pinfo, proto_tree *tree)
{
    tvbuff_t *next_tvb;
    guint16 seg_off, pkt_len, rx_bytes;
    guint8 data_off, sub_off;
    gboolean frag_save, is_seg, reassembled = FALSE;

    /* If STT dissector is disabled, or if it's a non-STT TCP packet, hand off
     * to TCP dissector. It would be better if we could register as a heuristic
     * IP subdissector: then we could return FALSE for non-STT packets, and
     * none of the following hackery would be necessary.
     */
    if (pref_disable || tvb_get_ntohs(tvb, STT_TCP_OFF_DPORT) != STT_PORT) {
        /* Remove ':stt' from 'Protocols in frame' field in Ethernet tree. */
        if (pinfo->layer_names) {
            g_string_truncate(pinfo->layer_names, pinfo->layer_names->len
                              - (sizeof(":stt") - 1));
        }
        call_dissector(tcp_dissector, tvb, pinfo, tree);
        return;
    }

    frag_save = pinfo->fragmented;
    seg_off = tvb_get_ntohs(tvb, STT_TCP_OFF_SEG_OFF);
    data_off = hi_nibble(tvb_get_guint8(tvb, STT_TCP_OFF_DATA_OFF)) * 4;

    /* Populate tree display if user has it open. */
    if (tree) {
        dissect_stt_tree(tvb, tree, seg_off, data_off);
    }

    pkt_len = tvb_get_ntohs(tvb, STT_TCP_OFF_PKT_LEN);
    rx_bytes = tvb_length_remaining(tvb, data_off);
    is_seg = pkt_len > rx_bytes;

    /* Reassemble segments unless the user has disabled reassembly. */
    if (is_seg && pref_reassemble) {
        tvbuff_t *reasm_tvb;

        pinfo->fragmented = TRUE;
        reasm_tvb = handle_segment(tvb, pinfo, tree, pkt_len, seg_off, data_off);
        if (reasm_tvb) {
            tvb = reasm_tvb;
            reassembled = TRUE;
            pinfo->fragmented = frag_save;
            is_seg = FALSE;
        }
    }

    /* Only first segment has STT header (following fake TCP header). */
    if (seg_off == 0 || reassembled) {
        sub_off = data_off + STT_HEADER_SIZE;
    } else {
        sub_off = data_off;
    }

    next_tvb = tvb_new_subset(tvb, sub_off, -1, -1);

    /* Only dissect inner frame if not segmented or if reassembled. */
    if (!is_seg) {
        call_dissector(eth_dissector, next_tvb, pinfo, tree);
    } else {
        call_dissector(data_dissector, next_tvb, pinfo, tree);
    }

    pinfo->fragmented = frag_save;
}

void
proto_register_stt(void)
{
    static const char *name = "Stateless TCP Tunnel protocol";
    static const char *short_name = "STT";
    static const char *filter_name = "stt";

    static hf_register_info hf[] = {
        /* Overloaded fake TCP header fields. */
        { &hf_stream_id,
          { "stream ID", "stt.stream_id",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_dport,
          { "destination port", "stt.dport",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_pkt_len,
          { "packet length", "stt.pkt_len",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_seg_off,
          { "segment offset", "stt.seg_off",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_pkt_id,
          { "packet ID", "stt.pkt_id",
            FT_UINT32, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_data_off,
          { "data offset", "stt.data_off",
            FT_UINT32, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },

        /* Segment reassembly information. */
        { &hf_segment_overlap,
          { "Segment overlap", "stt.segment.overlap",
            FT_BOOLEAN, BASE_NONE, NULL, 0x0,
            "Segment overlaps with other segments", HFILL }},

        { &hf_segment_overlap_conflict,
          { "Conflicting data in segment overlap", "stt.segment.overlap.conflict",
            FT_BOOLEAN, BASE_NONE, NULL, 0x0,
            "Overlapping segments contained conflicting data", HFILL }},

        { &hf_segment_multiple_tails,
          { "Multiple tail segments found", "stt.segment.multipletails",
            FT_BOOLEAN, BASE_NONE, NULL, 0x0,
            "Several tails were found when reassembling the pdu", HFILL }},

        { &hf_segment_too_long_fragment,
          { "Segment too long", "stt.segment.toolongfragment",
            FT_BOOLEAN, BASE_NONE, NULL, 0x0,
            "Segment contained data past end of the pdu", HFILL }},

        { &hf_segment_error,
          { "Reassembling error", "stt.segment.error",
            FT_FRAMENUM, BASE_NONE, NULL, 0x0,
            "Reassembling error due to illegal segments", HFILL }},

        { &hf_segment,
          { "STT Segment", "stt.segment",
            FT_FRAMENUM, BASE_NONE, NULL, 0x0,
            NULL, HFILL }},

        { &hf_segments,
          { "Reassembled STT Segments", "stt.segments",
            FT_NONE, BASE_NONE, NULL, 0x0,
            "STT Segments", HFILL }},

        { &hf_reassembled_in,
          { "Reassembled PDU in frame", "stt.reassembled_in",
            FT_FRAMENUM, BASE_NONE, NULL, 0x0,
            "The PDU that doesn't end in this segment is reassembled in this frame", HFILL }},

        { &hf_reassembled_length,
          { "Reassembled STT length", "stt.reassembled.length",
            FT_UINT32, BASE_DEC, NULL, 0x0,
            "The total length of the reassembled payload", HFILL }},

        /* STT header fields. */
        { &hf_version,
          { "version", "stt.version",
            FT_UINT8, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_flags,
          { "Flags", "stt.flags",
            FT_UINT8, BASE_HEX, NULL, 0x0, "STT flags", HFILL
          }
        },
        { &hf_flag_csum_verified,
          { "Checksum verified", "stt.flags.csum_verified",
            FT_BOOLEAN, STT_FLAGS_WIDTH, TFS(&tfs_set_notset), 0x0, NULL, HFILL
          }
        },
        { &hf_flag_csum_partial,
          { "Partial checksum", "stt.flags.csum_partial",
            FT_BOOLEAN, STT_FLAGS_WIDTH, TFS(&tfs_set_notset), 0x0, NULL, HFILL
          }
        },
        { &hf_flag_proto_ipv4,
          { "IPv4 protocol", "stt.flags.proto_ipv4",
            FT_BOOLEAN, STT_FLAGS_WIDTH, TFS(&tfs_set_notset), 0x0, NULL, HFILL
          }
        },
        { &hf_flag_proto_tcp,
          { "TCP protocol", "stt.flags.proto_tcp",
            FT_BOOLEAN, STT_FLAGS_WIDTH, TFS(&tfs_set_notset), 0x0, NULL, HFILL
          }
        },
        { &hf_l4_offset,
          { "L4 offset", "stt.l4_offset",
            FT_UINT8, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_mss,
          { "MSS", "stt.mss",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_vlan_tci,
          { "VLAN TCI", "stt.vlan_tci",
            FT_UINT16, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        },
        { &hf_key,
          { "Tunnel key", "stt.key",
            FT_UINT64, BASE_DEC,
            NULL, 0x0,
            NULL, HFILL }
        }
    };

    static gint *ett[] = {
        &ett_stt,
        &ett_stt_stt,
        &ett_stt_stt_flags,
        &ett_segment,
        &ett_segments
    };

    module_t *stt_prefs;

    proto_stt = proto_register_protocol(name, short_name, filter_name);

    proto_register_field_array(proto_stt, hf, array_length(hf));
    proto_register_subtree_array(ett, array_length(ett));

    stt_prefs = prefs_register_protocol(proto_stt, NULL);
    prefs_register_bool_preference(stt_prefs, "disable",
                                   "Disable dissection of STT packets",
                                   "Passes all traffic through to TCP dissector without further processing",
                                   &pref_disable);
    prefs_register_bool_preference(stt_prefs, "reassemble",
                                   "Reassemble segmented STT packets",
                                   "Reassembles greater-than-MTU-sized STT packets broken into segments on transmit",
                                   &pref_reassemble);

    register_init_routine(stt_segment_init);
}

void
proto_reg_handoff_stt(void)
{
    dissector_table_t dtbl;
    dissector_handle_t stt_dissector;

    /* Save handle to TCP dissector before we supercede it. */
    dtbl = find_dissector_table("ip.proto");
    tcp_dissector = dissector_get_port_handle(dtbl, IP_PROTO_TCP);

    /* Now register STT dissector in place of TCP dissector. */
    stt_dissector = create_dissector_handle(dissect_stt, proto_stt);
    dissector_add("ip.proto", IP_PROTO_TCP, stt_dissector);

    /* Cache Ethernet dissector handle for sub-dissection. */
    eth_dissector = find_dissector("eth_withoutfcs");

    /* Cache data dissector handle for display of segment data. */
    data_dissector = find_dissector("data");
}
